 echo "Starting Universal Android Toolkit..."
 echo "Should Universal Android Toolkit crash, hit CTRL+C."
 echo "For any major bugs, please visit: http://github.com/Beatsleigher/UniversalAndroidToolkit."
 java -jar UniversalAndroidToolkit_Linux.jar
 echo "Universal Android Toolkit has exited."
 echo "Hit ENTER to exit."
 read